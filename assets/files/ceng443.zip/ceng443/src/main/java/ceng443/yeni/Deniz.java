package ceng443.yeni;

public class Deniz implements Ortam {

	public HareketSekli getHareketSekli() {
		return new Yuzmek();
	}

}
