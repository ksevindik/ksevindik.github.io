package ceng443;

public class Simulasyon {
	
	private Ortam ortam;
	
	public void hareketEttir(Hayvan...hayvanListesi) {
		for(Hayvan h:hayvanListesi) {
			if(ortam instanceof Kara && h instanceof YuruyenBalik) {
				((YuruyenBalik)h).setKarada(true);
			}
			h.hareketEt();
		}
	}

	public Ortam getOrtam() {
		return ortam;
	}

	public void setOrtam(Ortam ortam) {
		this.ortam = ortam;
	}
	
	
}
