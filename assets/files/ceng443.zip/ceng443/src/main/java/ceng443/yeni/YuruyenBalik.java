package ceng443.yeni;

public class YuruyenBalik extends Balik {
	
	@Override
	public void hareketEt(Ortam ortam) {
		ortam.getHareketSekli().hareketEt();
	}
	
	
}
