package ceng443.yeni;

public class Kara implements Ortam {

	public HareketSekli getHareketSekli() {
		return new Yurumek();
	}

}
