package ceng443;

public class YuruyenBalik extends Balik {
	private boolean karada;
	
	@Override
	public void hareketEt() {
		if(karada) {
			System.out.println("yürüyor...");
		} else {
			super.hareketEt();
		}
	}

	public boolean isKarada() {
		return karada;
	}

	public void setKarada(boolean karada) {
		this.karada = karada;
	}
	
	
}
