package ceng443.yeni;

public class Yurumek implements HareketSekli {

	public void hareketEt() {
		System.out.println("yürüyor...");
	}

}
