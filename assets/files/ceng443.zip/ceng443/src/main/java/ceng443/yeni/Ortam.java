package ceng443.yeni;

public interface Ortam {
	public HareketSekli getHareketSekli();
}
