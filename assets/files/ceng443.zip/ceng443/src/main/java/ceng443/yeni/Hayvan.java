package ceng443.yeni;

public abstract class Hayvan {
	private int bacakSayisi;
	private HareketSekli hareketSekli;

	public int getBacakSayisi() {
		return bacakSayisi;
	}

	public void setBacakSayisi(int bacakSayisi) {
		this.bacakSayisi = bacakSayisi;
	}
	
	public HareketSekli getHareketSekli() {
		return hareketSekli;
	}

	public void setHareketSekli(HareketSekli hareketSekli) {
		this.hareketSekli = hareketSekli;
	}

	public abstract void hareketEt(Ortam ortam);
	
}
