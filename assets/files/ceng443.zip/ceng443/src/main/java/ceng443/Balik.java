package ceng443;

public class Balik extends YuzenHayvan {

}
