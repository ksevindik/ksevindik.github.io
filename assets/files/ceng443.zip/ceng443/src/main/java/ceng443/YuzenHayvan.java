package ceng443;

public class YuzenHayvan extends Hayvan {

	@Override
	public void hareketEt() {
		System.out.println("yüzüyor...");
	}

}
