package ceng443;

public class Kara implements Ortam {

}
