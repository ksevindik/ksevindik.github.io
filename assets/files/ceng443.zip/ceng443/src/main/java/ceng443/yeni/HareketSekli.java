package ceng443.yeni;

public interface HareketSekli {
	public void hareketEt();
}
