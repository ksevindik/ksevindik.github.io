package ceng443.yeni;

public class Simulasyon {
	
	private Ortam ortam;
	
	public void hareketEttir(Hayvan...hayvanListesi) {
		for(Hayvan h:hayvanListesi) {
			h.hareketEt(ortam);
		}
	}

	public Ortam getOrtam() {
		return ortam;
	}

	public void setOrtam(Ortam ortam) {
		this.ortam = ortam;
	}
	
	
}
