package ceng443.yeni;

public class Simulator {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		Simulasyon s = new Simulasyon();
		Ortam ortam = (Ortam) Class.forName(args[0]).newInstance();
		s.setOrtam(ortam);
		
		s.hareketEttir(new Balik(),new YuruyenBalik());
	}

}
