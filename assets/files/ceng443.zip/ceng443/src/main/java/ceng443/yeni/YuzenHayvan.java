package ceng443.yeni;

public class YuzenHayvan extends Hayvan {
	
	public YuzenHayvan() {
		setHareketSekli(new Yuzmek());
	}

	@Override
	public void hareketEt(Ortam ortam) {
		getHareketSekli().hareketEt();
	}

}
