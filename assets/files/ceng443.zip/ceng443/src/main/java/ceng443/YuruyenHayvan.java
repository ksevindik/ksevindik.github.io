package ceng443;

public class YuruyenHayvan extends Hayvan {

	@Override
	public void hareketEt() {
		System.out.println("yürüyor");
	}

}
