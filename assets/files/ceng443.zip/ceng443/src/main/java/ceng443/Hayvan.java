package ceng443;

public abstract class Hayvan {
	private int bacakSayisi;

	public int getBacakSayisi() {
		return bacakSayisi;
	}

	public void setBacakSayisi(int bacakSayisi) {
		this.bacakSayisi = bacakSayisi;
	}
	
	public abstract void hareketEt();
	
}
