package ceng443.yeni;

import org.junit.Test;

public class SimulasyonTests {
	
	@Test
	public void testBaliklarKarada() {
		Simulasyon s = new Simulasyon();
		s.setOrtam(new Deniz());
		s.hareketEttir(new Balik(), new YuruyenBalik());
	}
}
