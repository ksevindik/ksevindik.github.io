package ceng443;

public interface Ortam {

}
