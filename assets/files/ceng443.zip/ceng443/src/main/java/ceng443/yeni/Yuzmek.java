package ceng443.yeni;

public class Yuzmek implements HareketSekli {

	public void hareketEt() {
		System.out.println("yüzüyor...");
	}

}
