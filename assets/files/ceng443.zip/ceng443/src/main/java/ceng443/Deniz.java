package ceng443;

public class Deniz implements Ortam {

}
