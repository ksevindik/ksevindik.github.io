package ceng443;

import org.junit.Test;

public class SimulasyonTests {
	@Test
	public void testBaliklar() {
		Simulasyon s = new Simulasyon();
		s.hareketEttir(new Balik(), new YuruyenBalik());
	}
	
	@Test
	public void testBaliklarKarada() {
		Simulasyon s = new Simulasyon();
		s.setOrtam(new Kara());
		s.hareketEttir(new Balik(), new YuruyenBalik());
	}
}
