package ceng443.yeni;

public class Balik extends YuzenHayvan {

}
